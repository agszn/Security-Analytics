from .models import *
from django.contrib import admin


@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ["id", "name", "email", "message"]

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ["id", "consumer", "comment", "rating"]
from django.contrib import admin
from .models import BlogPost, Comment

class BlogPostAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'original_post', 'display_original_author', 'created_at', 'total_likes', 'total_dislikes', 'total_shares')
    search_fields = ('title', 'content', 'author__username', 'original_post__title', 'original_post__author__username')

    def display_original_author(self, obj):
        return obj.original_post.author.username if obj.original_post else 'N/A'
    display_original_author.short_description = 'Original Author'

    def total_likes(self, obj):
        return obj.total_likes()

    def total_dislikes(self, obj):
        return obj.total_dislikes()

    def total_shares(self, obj):
        return obj.total_shares()

admin.site.register(BlogPost, BlogPostAdmin)
admin.site.register(Comment)


admin.site.register(EncryptedData)