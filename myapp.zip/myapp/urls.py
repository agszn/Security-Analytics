from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.base, name='base'),
    path('about/', views.about, name='about'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('dashvalues/', views.dashvalues, name='dashvalues'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    # password change
    path('password_change/', auth_views.PasswordChangeView.as_view(), name='password_change'),
    path('password_change/done/', auth_views.PasswordChangeDoneView.as_view(), name='password_change_done'),

    # reset password
    path('password_reset/', auth_views.PasswordResetView.as_view(
        template_name='registration/password_reset_form.html',
        email_template_name='registration/password_reset_email.html',
        subject_template_name='registration/password_reset_subject.txt'
    ), name='password_reset'),

    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(
        template_name='registration/password_reset_done.html'
    ), name='password_reset_done'),

    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(
        template_name='registration/password_reset_confirm.html'
    ), name='password_reset_confirm'),

    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(
        template_name='registration/password_reset_complete.html'
    ), name='password_reset_complete'),

    # user registration
    path('register/', views.register, name='register'),

    # profile
    path('profile/', views.profile, name='profile'),
    path('edit-profile/', views.edit_profile, name='edit_profile'),
    path('delete-account/', views.delete_account, name='delete_account'),

    # contact
    path('contact/', views.contact, name='contact'),

    # review
    # path('add_review/<int:consumer_id>/', views.add_review, name='add_review'),
    # path('view_reviews/<int:consumer_id>/', views.view_reviews, name='view_reviews'),

    # notification
    # path('notifications/', views.user_notifications, name='user_notifications'),

    # email
    # path('send_email/', views.send_email, name='send_email'),

    # chat
    path('chat/', views.chat, name='chat'),

    # blog
    path('post_list/', views.post_list, name='post_list'),
    path('post/new/', views.post_new, name='post_new'),
    path('post/<int:post_id>/', views.post_detail, name='post_detail'),
    path('post/<int:post_id>/edit/', views.post_edit, name='post_edit'),
    path('post/<int:post_id>/delete/', views.post_delete, name='post_delete'),
    path('post/<int:post_id>/reshare/', views.reshare_post, name='reshare_post'),
    path('post/<int:post_id>/like/', views.like_post, name='like_post'),
    path('post/<int:post_id>/dislike/', views.dislike_post, name='dislike_post'),
    path('user/<int:user_id>/', views.user_posts, name='user_posts'),

    path('download/<int:post_id>/', views.download_post, name='download_post'),
    path('blogNotifications/', views.blogNotifications, name='blogNotifications'),

    # phishing detection
    path('check_phishing/', views.CheckPhishingView.as_view(), name='check_phishing'),

    # security cc
    path('backup/', views.backup_view, name='backup'),
    path('backup_success/', views.backup_success_view, name='backup_success'),

    path('mfa/', views.mfa_view, name='mfa'),
    path('mfa_success/', views.mfa_success_view, name='mfa_success'),
    path('mfa_failure/', views.mfa_failure_view, name='mfa_failure'),

    # encryption_decryption
    path('encrypt/', views.encrypt_view, name='encrypt'),
    path('decrypt/', views.decrypt_view, name='decrypt'),
    path('encryption_success/', views.encryption_success_view, name='encryption_success'),
    path('decryption_success/', views.decryption_success_view, name='decryption_success'),
    path('decryption_failure/', views.decryption_failure_view, name='decryption_failure'),
    path('hide_message/', views.hide_message_view, name='hide_message'),
    path('reveal_message/', views.reveal_message_view, name='reveal_message'),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
