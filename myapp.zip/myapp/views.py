from django.shortcuts import render, redirect,  get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from .forms import *
from .models import *
from django.db.models import Q

from django.http import JsonResponse
from django.conf import settings
import os

import joblib
import numpy as np

def base(request):
    return render(request, 'base.html')

def about(request):
    return render(request, 'about/about.html')

def register(request):
    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        if user_form.is_valid():
            #create a new registration object and avoid saving it yet
            new_user = user_form.save(commit=False)
            #reset the choosen password
            new_user.set_password(user_form.cleaned_data['password'])
            #save the new registration
            new_user.save()
            return render(request, 'registration/register_done.html',{'new_user':new_user})
    else:
        user_form = UserRegistrationForm()
    return render(request, 'registration/register.html',{'user_form':user_form})

def profile(request):
    return render(request, 'profile/profile.html')



@login_required
def edit_profile(request):
    if request.method == 'POST':
        user_form = EditProfileForm(request.POST, request.FILES, instance=request.user)
        if user_form.is_valid():
            user = user_form.save()
            profile = user.profile
            if 'profile_picture' in request.FILES:
                profile.profile_picture = request.FILES['profile_picture']
            profile.save()
            messages.success(request, 'Your profile was successfully updated!')
            return redirect('profile')
    else:
        user_form = EditProfileForm(instance=request.user)
    
    return render(request, 'profile/edit_profile.html', {'user_form': user_form})

@login_required
def delete_account(request):
    if request.method == 'POST':
        request.user.delete()
        messages.success(request, 'Your account was successfully deleted.')
        return redirect('base')  # Redirect to the homepage or another page after deletion

    return render(request, 'registration/delete_account.html')
# das
@login_required
def dashboard(request):
    users_count = User.objects.all().count()
    consumers = Consumer.objects.all().count
    notify_users = Notification.objects.all().count()
    review_count = Review.objects.all().count()

    context = {
        'users_count':users_count,
        'consumers':consumers,
        'notify_users':notify_users,
        'review_count':review_count,
        'barData': [10, 20, 30],
        'lineData': [30, 25, 35],
        'pieData': [10, 40, 50],
        'scatterData': [{'x': 10, 'y': 20}, {'x': 15, 'y': 10}, {'x': 20, 'y': 30}],
        
    }
    return render(request, "dashboard/dashboard_crop.html", context=context)
#CRUD operations start here
@login_required
def dashvalues(request):
    consumers = Consumer.objects.all()
    search_query = ""
    
    if request.method == "POST": 
        if "create" in request.POST:
            name = request.POST.get("name")
            email = request.POST.get("email")
            image = request.FILES.get("image")
            content = request.POST.get("content")

            Consumer.objects.create(
                name=name,
                email=email,
                image=image,
                content=content
            )
            messages.success(request, "Consumer added successfully")
    
        elif "update" in request.POST:
            id = request.POST.get("id")
            name = request.POST.get("name")
            email = request.POST.get("email")
            image = request.FILES.get("image")
            content = request.POST.get("content")

            consumer = get_object_or_404(Consumer, id=id)
            consumer.name = name
            consumer.email = email
            consumer.image = image
            consumer.content = content
            consumer.save()
            messages.success(request, "Consumer updated successfully")
    
        elif "delete" in request.POST:
            id = request.POST.get("id")
            Consumer.objects.get(id=id).delete()
            messages.success(request, "Consumer deleted successfully")
        
        elif "search" in request.POST:
            search_query = request.POST.get("query")
            consumers = Consumer.objects.filter(Q(name__icontains=search_query) | Q(email__icontains=search_query))

    context = {
        "consumers": consumers, 
        "search_query": search_query
    }
    return render(request, "crud/dashvalue.html", context=context)
# CRUD operations end here

# Contact start
@login_required
def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Thank you for contacting us!")
            return redirect('dashboard')  # Redirect to the same page to show the modal
    else:
        form = ContactForm()

    return render(request, 'contact/contact_form.html', {'form': form})

# contact end
@login_required
def chat(request):
    return render(request, 'chat/chat.html')

# blog posts
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from .forms import BlogPostForm, CommentForm
from .models import BlogPost, Comment
from django.contrib.auth.models import User

@login_required
def post_list(request):
    # Order posts by created date in descending order to get the latest post first
    posts = BlogPost.objects.all().order_by('-created_at')
    users = User.objects.all()  # Query to fetch all users

    context = {
        'posts': posts,
        'user': request.user,
        'users': users,  # Include users in the context
    }
    return render(request, 'blog/post_list.html', context)


@login_required
def post_new(request):
    if request.method == "POST":
        form = BlogPostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            return redirect('post_list')
    else:
        form = BlogPostForm()
    return render(request, 'blog/post_new.html', {'form': form})

@login_required
def reshare_post(request, post_id):
    original_post = get_object_or_404(BlogPost, id=post_id)
    if request.method == "POST":
        form = BlogPostForm(request.POST, request.FILES)
        if form.is_valid():
            reshared_post = form.save(commit=False)
            reshared_post.author = request.user
            reshared_post.original_post = original_post
            reshared_post.save()
            return redirect('post_list')
    else:
        form = BlogPostForm(initial={
            'title': original_post.title, 
            'content': original_post.content, 
            'image': original_post.image, 
            'video': original_post.video
        })
    return render(request, 'blog/reshare_post.html', {'form': form, 'original_post': original_post})

@login_required
def post_detail(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id)
    if request.method == 'POST':
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.post = post
            comment.author = request.user
            comment.save()
            return redirect('post_detail', post_id=post.id)
    else:
        comment_form = CommentForm()
    return render(request, 'blog/post_detail.html', {'post': post, 'comment_form': comment_form})

@login_required
def like_post(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id)
    if request.user in post.likes.all():
        post.likes.remove(request.user)
    else:
        post.likes.add(request.user)
        post.dislikes.remove(request.user)  # Ensure the user cannot dislike the post if they like it
    return redirect('post_detail', post_id=post.id)

@login_required
def dislike_post(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id)
    if request.user in post.dislikes.all():
        post.dislikes.remove(request.user)
    else:
        post.dislikes.add(request.user)
        post.likes.remove(request.user)  # Ensure the user cannot like the post if they dislike it
    return redirect('post_detail', post_id=post.id)

@login_required
def post_edit(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id)
    if request.user != post.author:
        return HttpResponseForbidden()
    if request.method == "POST":
        form = BlogPostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            return redirect('post_detail', post_id=post.id)
    else:
        form = BlogPostForm(instance=post)
    return render(request, 'blog/post_edit.html', {'form': form, 'post': post})

@login_required
def post_delete(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id)
    if request.user != post.author:
        return HttpResponseForbidden()
    post.delete()
    return redirect('post_list')

@login_required
def user_posts(request, user_id):
    user = get_object_or_404(User, id=user_id)
    posts = BlogPost.objects.filter(author=user)
    return render(request, 'blog/user_posts.html', {'posts': posts, 'user_profile': user})

from django.core.mail import send_mail
from django.conf import settings
from django.http import HttpResponse
from django.utils.text import slugify

@login_required
def download_post(request, post_id):
    post = get_object_or_404(BlogPost, id=post_id)
    
    # Content to be downloaded
    # content = f"Title: {post.title}\n\n{post.content}"
    # response = HttpResponse(content, content_type='text/plain')
    # response['Content-Disposition'] = f'attachment; filename={slugify(post.title)}.txt'
    
    # Notify the author via email
    # send_mail(
    #     'Your post has been downloaded',
    #     f'Hello {post.author.username},\n\nYour post "{post.title}" was downloaded by {request.user.username}.',
    #     settings.DEFAULT_FROM_EMAIL,
    #     [post.author.email],
    # )
    
    # Create a notification entry for the author
    notification_message = f'Your post "{post.title}" was downloaded by {request.user.username}.'
    BlogNotification.objects.create(user=post.author, message=notification_message)
    
    # return response
    return redirect('blogNotifications')


@login_required
def blogNotifications(request):
    notifications = request.user.notifications.filter(is_read=False)
    return render(request, 'blog/notifications.html', {'notifications': notifications})

# phishing url
# myapp/views.py
from django.shortcuts import render
from django.views import View
from .utils import is_phishing_url

class CheckPhishingView(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'phishing/check_phishing.html', {'result': None})

    def post(self, request, *args, **kwargs):
        url = request.POST.get('url', '')
        is_phishing = is_phishing_url(url)
        result = {
            'url': url,
            'is_phishing': is_phishing
        }
        return render(request, 'phishing/check_phishing.html', {'result': result})

# cc
from django.shortcuts import render, redirect
from .models import EncryptedData
from .forms import EncryptForm, DecryptForm
from cryptography.fernet import Fernet
import os
import shutil
from datetime import datetime
import pyotp

# Backup Functionality

# View to handle database backup requests
def backup_view(request):
    backup_dir = "backups"
    # Create backup directory if it does not exist
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)

    # Create a timestamp for the backup
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    backup_subdir = os.path.join(backup_dir, timestamp)
    os.makedirs(backup_subdir)
    
    # Copy the database file to the backup subdirectory
    shutil.copy("db.sqlite3", os.path.join(backup_subdir, "db.sqlite3"))

    return redirect('backup_success')

# View to render success message after backup
def backup_success_view(request):
    return render(request, 'securityapp/backup_success.html')

# MFA Functionality

# Generate a new secret for TOTP
def generate_secret():
    return pyotp.random_base32()

# Get the current TOTP code for the given secret
def get_totp(secret):
    totp = pyotp.TOTP(secret)
    return totp.now()

# Verify the given TOTP code against the secret
def verify_totp(secret, code):
    totp = pyotp.TOTP(secret)
    return totp.verify(code)

# View to handle MFA requests
def mfa_view(request):
    secret = generate_secret()
    if request.method == "POST":
        code = request.POST.get('code')
        if verify_totp(secret, code):
            return redirect('mfa_success')
        else:
            return redirect('mfa_failure')
    totp_code = get_totp(secret)
    return render(request, 'securityapp/mfa.html', {'secret': secret, 'totp_code': totp_code})

# View to render success message after MFA
def mfa_success_view(request):
    return render(request, 'securityapp/mfa_success.html')

# View to render failure message if MFA fails
def mfa_failure_view(request):
    return render(request, 'securityapp/mfa_failure.html')


# Encryption and Decryption Functions
# views.py
from django.shortcuts import render, redirect
from .forms import EncryptForm, DecryptForm, HideMessageForm, RevealMessageForm
from .models import EncryptedData
from cryptography.fernet import Fernet
from PIL import Image
import os
import shutil
from datetime import datetime
import pyotp
from django.http import HttpResponseRedirect
from django.urls import reverse

# views.py

from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from django.urls import reverse
from .models import EncryptedData
from .forms import EncryptForm, DecryptForm
from cryptography.fernet import Fernet
import os
import shutil
from datetime import datetime
import pyotp

# Encryption and Decryption Functions
def generate_key():
    key = Fernet.generate_key()
    with open("secret.key", "wb") as key_file:
        key_file.write(key)

def load_key():
    return open("secret.key", "rb").read()

def encrypt_data(data):
    key = load_key()
    fernet = Fernet(key)
    encrypted_data = fernet.encrypt(data.encode())
    return encrypted_data

def decrypt_data(encrypted_data):
    key = load_key()
    fernet = Fernet(key)
    decrypted_data = fernet.decrypt(encrypted_data).decode()
    return decrypted_data

# Encryption View
def encrypt_view(request):
    if not os.path.exists("secret.key"):
        generate_key()

    if request.method == "POST":
        form = EncryptForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data['data']
            encrypted = encrypt_data(data)
            EncryptedData.objects.create(data=encrypted)
            return HttpResponseRedirect(reverse('encryption_success') + f'?encrypted_text={encrypted.decode()}')
    else:
        form = EncryptForm()

    return render(request, 'securityapp/encrypt.html', {'form': form})

def encryption_success_view(request):
    encrypted_text = request.GET.get('encrypted_text', '')
    return render(request, 'securityapp/encryption_success.html', {'encrypted_text': encrypted_text})

# Decryption View
def decrypt_view(request):
    decrypted_text = None
    if request.method == "POST":
        form = DecryptForm(request.POST)
        if form.is_valid():
            encrypted_text = form.cleaned_data['encrypted_text']
            try:
                decrypted_text = decrypt_data(encrypted_text.encode())
                return HttpResponseRedirect(reverse('decryption_success') + f'?decrypted_text={decrypted_text}&encrypted_text={encrypted_text}')
            except Exception as e:
                return HttpResponseRedirect(reverse('decryption_failure') + f'?error={str(e)}')
    else:
        form = DecryptForm()

    return render(request, 'securityapp/decrypt.html', {'form': form, 'decrypted_text': decrypted_text})

def decryption_success_view(request):
    decrypted_text = request.GET.get('decrypted_text', '')
    encrypted_text = request.GET.get('encrypted_text', '')
    return render(request, 'securityapp/decryption_success.html', {'decrypted_text': decrypted_text, 'encrypted_text': encrypted_text})

def decryption_failure_view(request):
    error = request.GET.get('error', 'Unknown error')
    return render(request, 'securityapp/decryption_failure.html', {'error': error})


# Steganography Functions
from django.shortcuts import render, redirect
from .forms import HideMessageForm, RevealMessageForm
from PIL import Image
import numpy as np
import base64

from django.shortcuts import render, redirect
from .forms import HideMessageForm, RevealMessageForm
from PIL import Image
import numpy as np
import base64

def encode_message_in_image(image_path, message, output_path):
    image = Image.open(image_path)
    image = np.array(image)
    binary_message = ''.join(format(ord(char), '08b') for char in message)
    binary_message += '1111111111111110'  # end of message delimiter
    
    data_index = 0
    for values in image:
        for pixel in values:
            for n in range(3):  # loop through RGB channels
                if data_index < len(binary_message):
                    pixel[n] = int(bin(pixel[n])[2:-1] + binary_message[data_index], 2)
                    data_index += 1
                else:
                    break

    encoded_image = Image.fromarray(image)
    encoded_image.save(output_path)

def decode_message_from_image(image_path):
    try:
        image = Image.open(image_path)
        image = np.array(image)
        binary_message = ''
        
        for values in image:
            for pixel in values:
                for n in range(3):  # loop through RGB channels
                    binary_message += bin(pixel[n])[2:][-1]
        
        all_bytes = [binary_message[i: i+8] for i in range(0, len(binary_message), 8)]
        decoded_message = ''
        for byte in all_bytes:
            decoded_message += chr(int(byte, 2))
            if decoded_message[-2:] == 'ÿþ':  # stop condition
                break
        return decoded_message[:-2]
    except Exception as e:
        raise e

def hide_message_view(request):
    if request.method == 'POST':
        form = HideMessageForm(request.POST, request.FILES)
        if form.is_valid():
            image = form.cleaned_data['image']
            message = form.cleaned_data['message']
            output_image_path = 'output_image.png'
            encode_message_in_image(image, message, output_image_path)
            with open(output_image_path, "rb") as image_file:
                encoded_image = base64.b64encode(image_file.read()).decode('utf-8')
            return render(request, 'securityapp/hide_success.html', {'encoded_image': encoded_image})
    else:
        form = HideMessageForm()
    return render(request, 'securityapp/hide_message.html', {'form': form})

def reveal_message_view(request):
    if request.method == 'POST':
        form = RevealMessageForm(request.POST, request.FILES)
        if form.is_valid():
            image = form.cleaned_data['image']
            try:
                decoded_message = decode_message_from_image(image)
                return render(request, 'securityapp/reveal_success.html', {'decoded_message': decoded_message})
            except Exception as e:
                return render(request, 'securityapp/reveal_failure.html', {'error': str(e)})
    else:
        form = RevealMessageForm()
    return render(request, 'securityapp/reveal_message.html', {'form': form})
